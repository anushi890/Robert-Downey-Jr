const express = require('express');
const path = require('path');
const { render } = require('ejs');
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'))

app.use(express.static(path.join(__dirname, "public")));

app.get('/', (req, res) => {
    res.render('homepage');
})

app.listen(3000, () => {
    console.log("listening to port 3000");
})